//
//  SecondViewController.swift
//  HRProject
//
//  Created by Fatma Buyabes on 29/02/2024.
//

import UIKit
import SnapKit
class SecondViewController: UIViewController {
    
    var nameData: String?
    var emailData: String?
    var phoneData: String?
    var imageData: String?
    var salaryData: String?
    var ibanData: String?
    
    let nameLabel = UILabel()
    let phoneLabel = UILabel()
    let emailLabel = UILabel()
    let salaryLabel = UILabel()
    let ibnLabel = UILabel()
    let img = UIImageView()
    
    let emailSymbol = UIImageView(image: UIImage(systemName: "envelope"))
    let phoneSymbol = UIImageView(image: UIImage(systemName: "phone"))
    let salarySymbol = UIImageView(image: UIImage(systemName: "dollarsign.circle"))
    let ibnSymbol = UIImageView(image: UIImage(systemName: "creditcard"))
    
    
    let informationContainerView = UIView()
    
    override func viewDidLoad() {
        title = "Information Details "
        
        view.backgroundColor = .white
        
        super.viewDidLoad()
        //help by awdhah 🤍
        img.image = UIImage(named: imageData!)
        
        
        subViews()
        setupAutoLayout()
        setupUi()
        nameLabel.text = nameData
        ibnLabel.text = ibanData
        emailLabel.text = emailData
        salaryLabel.text = salaryData
        phoneLabel.text = phoneData
        
        
        
        
        // Do any additional setup after loading the view.
    }
    func subViews(){
        //        view.addSubview(nameLabel)
        //        view.addSubview(emailLabel)
        //        view.addSubview(phoneLabel)
        //        view.addSubview(salaryLabel)
        //        view.addSubview(ibnLabel)
        view.addSubview(phoneSymbol)
        view.addSubview(emailSymbol)
        view.addSubview(ibnSymbol)
        view.addSubview(salarySymbol)
        view.addSubview(img)
        view.addSubview(informationContainerView)
        informationContainerView.addSubview(nameLabel)
        informationContainerView.addSubview(emailLabel)
        informationContainerView.addSubview(phoneLabel)
        informationContainerView.addSubview(salaryLabel)
        informationContainerView.addSubview(ibnLabel)
        
        
    }
    
    func setupUi(){
        nameLabel.textColor = .black
        nameLabel.font = UIFont.boldSystemFont(ofSize: 25)
        emailLabel.font = UIFont.systemFont(ofSize: 18)
        phoneLabel.font = UIFont.systemFont(ofSize: 18)
        salaryLabel.font = UIFont.systemFont(ofSize: 18)
        ibnLabel.font = UIFont.systemFont(ofSize: 18)
        img.layer.cornerRadius = 37.5
        img.clipsToBounds = true
        informationContainerView.backgroundColor = .lightGray
        emailSymbol.tintColor = .lightGray
        ibnSymbol.tintColor = .lightGray
        phoneSymbol.tintColor = .lightGray
        salarySymbol.tintColor = .lightGray
    }
    
    func setupAutoLayout(){
        emailSymbol.snp.makeConstraints { make in
            make.trailing.equalTo(emailLabel.snp.leading).offset(-5)
            make.centerY.equalTo(emailLabel)
            
        }
        phoneSymbol.snp.makeConstraints { make in
            make.trailing.equalTo(phoneLabel.snp.leading).offset(-5)
            make.centerY.equalTo(phoneLabel)
            
        }
        salarySymbol.snp.makeConstraints { make in
            make.trailing.equalTo(salaryLabel.snp.leading).offset(-5)
            make.centerY.equalTo(salaryLabel)
        }
        ibnSymbol.snp.makeConstraints { make in
            make.trailing.equalTo(ibnLabel.snp.leading).offset(-5)
            make.centerY.equalTo(ibnLabel)
        }
        img.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(0)
            make.leading.equalToSuperview().offset(10)
            make.width.height.equalTo(85)
        }
        
        nameLabel.snp.makeConstraints { make in
            make.leading.equalTo(img.snp.trailing ).offset(20)
            make.centerY.equalTo(img.snp.centerY)
            
        }
        
        emailLabel.snp.makeConstraints { make in
            make.leading.equalTo(nameLabel).offset(20)
            make.top.equalTo(nameLabel.snp.bottom).offset(20)
        }
        phoneLabel.snp.makeConstraints { make in
            make.leading.equalTo(emailLabel)
            make.top.equalTo(emailLabel).offset(40)
        }
        salaryLabel.snp.makeConstraints { make in
            make.leading.equalTo(phoneLabel)
            make.top.equalTo(ibnLabel).offset(40)
        }
        
        ibnLabel.snp.makeConstraints { make in
            make.leading.equalTo(salaryLabel)
            make.top.equalTo(phoneLabel).offset(40)
        }
        
        informationContainerView.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(120)        }
        
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }
}
