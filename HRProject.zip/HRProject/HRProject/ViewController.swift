//
//  ViewController.swift
//  HRProject
//
//  Created by Fatma Buyabes on 29/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    let image = UIImageView()
    let nameTextField = UITextField()
    let emailTextField = UITextField()
    let phoneTextField = UITextField()
    let employeeSalaryTextField = UITextField()
    let ibanTextField = UITextField()
    let imageTextField = UITextField()
    let nametext = UILabel()
    let phonetext = UILabel()
    let emailtext = UILabel()
    let salarytext = UILabel()
    let ibantext = UILabel()
    let imgtext = UILabel()
    let saveButton = UIButton(type: .custom)
    
    
    
    override func viewDidLoad() {
        title = "Details View "
        view.backgroundColor = .white

        super.viewDidLoad()
        // Do any additional setup after loading the view.
        phoneTextField.delegate = self
        view.addSubview(nameTextField)
        view.addSubview(emailTextField)
        view.addSubview(phoneTextField)
        view.addSubview(employeeSalaryTextField)
        view.addSubview(ibanTextField)
        view.addSubview(imageTextField)
        view.addSubview(saveButton)
        view.addSubview(salarytext)
        view.addSubview(emailtext)
        view.addSubview(phonetext)
        view.addSubview(nametext)
        view.addSubview(imgtext)
        view.addSubview(ibantext)
        setUpUi()
        setUpNavigationBar()
        setupAutoLayout()
        setupNavigationBar( )
        saveButton.addTarget(self, action: #selector(SaveDetailsTapped), for: .touchUpInside)
        
        // Do any additional setup after loading the view.
    }
    
    func setUpUi(){
        imgtext.text = "Image : "
        nametext.text = "Name: "
        phonetext.text = "Phone: "
        emailtext.text = "Email: "
        salarytext.text = "Salary: "
        ibantext.text = "IBAN: "
        
        imgtext.font = UIFont.boldSystemFont(ofSize: 18)
        nametext.font = UIFont.boldSystemFont(ofSize: 18)
        emailtext.font = UIFont.boldSystemFont(ofSize: 18)
        phonetext.font = UIFont.boldSystemFont(ofSize: 18)
        salarytext.font = UIFont.boldSystemFont(ofSize: 18)
        ibantext.font = UIFont.boldSystemFont(ofSize: 18)
        
        nametext.textColor = .gray
        phonetext.textColor = .gray
        emailtext.textColor = .gray
        ibantext.textColor = .gray
        imgtext.textColor = .gray
        salarytext.textColor = . gray
        
        
        nameTextField.placeholder = "enter full name"  // text for the user
        nameTextField.font = UIFont.systemFont(ofSize: 17)
        nameTextField.textAlignment = .center
        nameTextField.layer.backgroundColor = UIColor.white.cgColor
        nameTextField.layer.borderWidth = 1
        nameTextField.layer.borderColor = UIColor.lightGray.cgColor
        nameTextField.layer.cornerRadius = 10
        
        emailTextField.placeholder = "enter email"  // text for the user
        emailTextField.font = UIFont.systemFont(ofSize: 17)
        emailTextField.textAlignment = .center
        emailTextField.layer.backgroundColor = UIColor.white.cgColor
        emailTextField.layer.borderWidth = 1
        emailTextField.layer.borderColor = UIColor.lightGray.cgColor
        emailTextField.layer.cornerRadius = 10
        
        
        phoneTextField.placeholder = "enter phone"  // text for the user
        phoneTextField.font = UIFont.systemFont(ofSize: 17)
        phoneTextField.textAlignment = .center
        phoneTextField.layer.backgroundColor = UIColor.white.cgColor
        phoneTextField.layer.borderWidth = 1
        phoneTextField.layer.borderColor = UIColor.lightGray.cgColor
        phoneTextField.layer.cornerRadius = 10
        
        employeeSalaryTextField.placeholder = "enter salary"  // text for the user
        employeeSalaryTextField.font = UIFont.systemFont(ofSize: 17)
        employeeSalaryTextField.textAlignment = .center
        employeeSalaryTextField.layer.backgroundColor = UIColor.white.cgColor
        employeeSalaryTextField.layer.borderWidth = 1
        employeeSalaryTextField.layer.borderColor = UIColor.lightGray.cgColor
        employeeSalaryTextField.layer.cornerRadius = 10
        
        ibanTextField.placeholder = "enter  IBAN "  // text for the user
        ibanTextField.font = UIFont.systemFont(ofSize: 17)
        ibanTextField.textAlignment = .center
        ibanTextField.layer.backgroundColor = UIColor.white.cgColor
        ibanTextField.layer.borderWidth = 1
        ibanTextField.layer.borderColor = UIColor.lightGray.cgColor
        ibanTextField.layer.cornerRadius = 10
        
        imageTextField.placeholder = "Profile2 "  // text for the user
        imageTextField.font = UIFont.systemFont(ofSize: 17)
        imageTextField.textAlignment = .center
        imageTextField.layer.backgroundColor = UIColor.white.cgColor
        imageTextField.layer.borderWidth = 1
        imageTextField.layer.borderColor = UIColor.lightGray.cgColor
        imageTextField.layer.cornerRadius = 10
        
        saveButton.setTitle(" Save", for: .normal) //why normal ?
        saveButton.backgroundColor = .black
        saveButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        saveButton.layer.cornerRadius = 10
        
        saveButton.layer.borderColor = UIColor.black.cgColor
        saveButton.tintColor = .white
        saveButton.setImage(UIImage(systemName: "square.and.arrow.down"), for: .normal)

        saveButton.backgroundColor = .darkGray
        
    }
    
    func setupAutoLayout(){
        
        
        nameTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(view.safeAreaLayoutGuide).offset(60)
            make.width.equalTo(220)
            make.height.equalTo(50)
            
        }
        
        emailTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(nameTextField.snp.bottom).offset(30)
            make.width.equalTo(220)
            make.height.equalTo(50)
           
        }
        phoneTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(emailTextField.snp.bottom).offset(30)
            make.width.equalTo(220)
            make.height.equalTo(50)
        }
        employeeSalaryTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(phoneTextField.snp.bottom).offset(30)
            make.width.equalTo(220)
            make.height.equalTo(50)
        }
        ibanTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(employeeSalaryTextField.snp.bottom).offset(30)
            make.width.equalTo(220)
            make.height.equalTo(50)
        }
        
        imageTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(ibanTextField.snp.bottom).offset(30)
            make.width.equalTo(220)
            make.height.equalTo(50)
        }
        
        saveButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // Center horizontally
            make.top.equalTo(imageTextField.snp.bottom).offset(70)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
        
        salarytext.snp.makeConstraints { make in
            make.right.equalTo(employeeSalaryTextField.snp.left).offset(-10)
            make.centerY.equalTo(employeeSalaryTextField)
        }
        
        nametext.snp.makeConstraints { make in
            make.right.equalTo(nameTextField.snp.left).offset(-10)
            make.centerY.equalTo(nameTextField)
        }
        phonetext.snp.makeConstraints { make in
            make.right.equalTo(phoneTextField.snp.left).offset(-10)
            make.centerY.equalTo(phoneTextField)
        }
        ibantext.snp.makeConstraints { make in
            make.right.equalTo(ibanTextField.snp.left).offset(-10)
            make.centerY.equalTo(ibanTextField)
        }
        emailtext.snp.makeConstraints { make in
            make.right.equalTo(emailTextField.snp.left).offset(-10)
            make.centerY.equalTo(emailTextField)
        }
        imgtext.snp.makeConstraints { make in
            make.right.equalTo(imageTextField.snp.left).offset(-10)
            make.centerY.equalTo(imageTextField)
        }
        
    }
    
    func setUpNavigationBar(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }
    
    @objc func SaveDetailsTapped(){
        let secondVC = SecondViewController()
        secondVC.nameData = nameTextField.text
        secondVC.emailData = emailTextField.text
        secondVC.phoneData = phoneTextField.text
        secondVC.ibanData = ibanTextField.text
        secondVC.salaryData = employeeSalaryTextField.text
        secondVC.imageData = imageTextField.text

        self.navigationController?.pushViewController(secondVC, animated: true)
        
    }
    
    func setupNavigationBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "info.circle.fill"),
            style: .plain,
            target: self,
            action: #selector(navIns)
        )
        navigationItem.leftBarButtonItem?.tintColor = UIColor.red
        
    }
    
    @objc func navIns(){
        let insVC = InstructionsViewController()
        insVC.modalPresentationStyle = .popover
        self.present(insVC, animated: true)
        
    }
    


}

extension ViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == phoneTextField {
            return (textField.text?.count ?? 0) + string.count - range.length <= 8
        }
        
        return true
    }
}

