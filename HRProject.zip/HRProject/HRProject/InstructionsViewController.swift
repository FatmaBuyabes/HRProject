//
//  InstructionsViewController.swift
//  HRProject
//
//  Created by Fatma Buyabes on 29/02/2024.
//

import UIKit
import SnapKit
class InstructionsViewController: UIViewController {

    let label1 = UILabel()
    let label2 = UILabel()
    let label3 = UILabel()
    let oneimageview = UIImageView(image: UIImage(systemName: "1.square"))
    let twoimageview = UIImageView(image: UIImage(systemName: "2.square"))
    let threeimageview = UIImageView(image: UIImage(systemName: "3.square"))

    
        override func viewDidLoad() {

        super.viewDidLoad()
        title = "Instructions"
        view.backgroundColor = .white
        label1.text = "Regular Reviews: Conduct periodic performance reviews to discuss goals, provide feedback, and support employee development"
                
        label2.text = "Open Communication: Establish clear channels for employees to communicate concerns, ideas, and feedback easily."
                
        label3.text = "Training Support: Offer training opportunities to help employees grow their skills and advance their careers."
        setUpLabels()
        setUpUi()
        setUpAutoLayout()
            
            

    }
    
    
    func setUpLabels(){
        view.addSubview(oneimageview)
        view.addSubview(twoimageview)
        view.addSubview(threeimageview)
        view.addSubview(label1)
        view.addSubview(label2)
        view.addSubview(label3)
        
    
    }
    
    func setUpUi(){
        
        label1.textColor = .darkGray
        label1.numberOfLines = 4 // Allow multiple lines
        label1.lineBreakMode = .byWordWrapping
        label1.font = UIFont.boldSystemFont(ofSize: 16)
        
        label2.textColor = .darkGray
        label2.numberOfLines = 4 // Allow multiple lines
        label2.lineBreakMode = .byWordWrapping
        label2.font = UIFont.boldSystemFont(ofSize: 16)
        
        label3.textColor = .darkGray
        label3.numberOfLines = 4 // Allow multiple lines
        label3.lineBreakMode = .byWordWrapping
        label3.font = UIFont.boldSystemFont(ofSize: 16)
        
        oneimageview.tintColor = .darkGray
        twoimageview.tintColor = .darkGray
        threeimageview.tintColor = .darkGray
    }
    
    func setUpAutoLayout(){
        
        oneimageview.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(30)
            make.top.equalTo(view.safeAreaLayoutGuide).offset(30)
            make.width.height.equalTo(30)
                }
        
        label1.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.left.equalTo(view.safeAreaLayoutGuide.snp.left).offset(30)
            make.top.equalTo(view.safeAreaLayoutGuide).offset(60)
            make.right.equalTo(view.safeAreaLayoutGuide.snp.right).offset(-20)

            //make.width.height.equalTo(100)
            
        }
        twoimageview.snp.makeConstraints { make in
                make.leading.equalToSuperview().offset(30)
                make.top.equalTo(label2).offset(-30)
                make.width.height.equalTo(30)
                }
        label2.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(label1.snp.bottom).offset(100)
            make.left.equalTo(label1.snp.left)
            make.right.equalTo(label1.snp.right)
            
            
        }
        threeimageview.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(30)
            make.top.equalTo(label3).offset(-30)
            make.width.height.equalTo(30)
                }
        label3.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(label2.snp.bottom).offset(100)
            make.left.equalTo(label1.snp.left)
            make.right.equalTo(label1.snp.right)
            make.bottom.lessThanOrEqualTo(view.safeAreaLayoutGuide.snp.bottom).offset(-50)
            
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
